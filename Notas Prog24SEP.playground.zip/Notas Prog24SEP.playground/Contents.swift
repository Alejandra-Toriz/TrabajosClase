//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"

/*
 el truco esta en el unwind,
 poner lo importante en la primera vista para que no se borre lo importante
 
 
 */
